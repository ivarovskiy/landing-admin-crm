import { NextResponse } from "next/server"
import { cookies } from "next/headers"

type P = { id: string }

export async function POST(req: Request, ctx: { params: P | Promise<P> }) {
  const token = (await cookies()).get("access_token")?.value
  if (!token) return NextResponse.json({ message: "Unauthorized" }, { status: 401 })

  const { id: pageId } = await Promise.resolve(ctx.params)
  const body = await req.json().catch(() => null)

  const apiUrl = process.env.API_URL ?? "http://localhost:3000"
  const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(pageId)}/blocks`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "content-type": "application/json",
    },
    body: JSON.stringify(body),
    cache: "no-store",
  })

  const text = await r.text()
  return new NextResponse(text, {
    status: r.status,
    headers: { "content-type": r.headers.get("content-type") ?? "application/json" },
  })
}