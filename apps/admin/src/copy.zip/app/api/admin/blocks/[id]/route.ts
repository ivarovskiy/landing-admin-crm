import { NextResponse } from "next/server"
import { cookies } from "next/headers"

type P = { id: string }

export async function PATCH(req: Request, ctx: { params: P | Promise<P> }) {
  const accessToken = (await cookies()).get("access_token")?.value
  if (!accessToken) return NextResponse.json({ message: "Unauthorized" }, { status: 401 })

  const { id } = await Promise.resolve(ctx.params)
  const body = await req.json().catch(() => null)

  const apiUrl = process.env.API_URL ?? "http://localhost:3000"
  const r = await fetch(`${apiUrl}/v1/admin/blocks/${encodeURIComponent(id)}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "content-type": "application/json",
    },
    body: JSON.stringify(body),
    cache: "no-store",
  })

  const text = await r.text()
  return new NextResponse(text, {
    status: r.status,
    headers: { "content-type": r.headers.get("content-type") ?? "application/json" },
  })
}

export async function DELETE(req: Request, ctx: { params: P | Promise<P> }) {
  const accessToken = (await cookies()).get("access_token")?.value
  if (!accessToken) return NextResponse.json({ message: "Unauthorized" }, { status: 401 })

  const { id } = await Promise.resolve(ctx.params)
  const apiUrl = process.env.API_URL ?? "http://localhost:3000"

  const r = await fetch(`${apiUrl}/v1/admin/blocks/${encodeURIComponent(id)}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${accessToken}` },
    cache: "no-store",
  })

  const text = await r.text()
  return new NextResponse(text || JSON.stringify({ ok: r.ok }), {
    status: r.status,
    headers: { "content-type": r.headers.get("content-type") ?? "application/json" },
  })
}