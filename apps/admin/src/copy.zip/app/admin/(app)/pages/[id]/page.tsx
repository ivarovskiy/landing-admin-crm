// import Link from "next/link";
// import { fetchAdminPage } from "@/lib/admin-api";
// import { Button } from "@/components/ui/button";
// import { cookies } from "next/headers";
// import { revalidatePath } from "next/cache";
// import { redirect } from "next/navigation";
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// import { Input } from "@/components/ui/input";
// import { AddBlockForm } from "@/components/add-block-form";
// import { DeleteBlockButton } from "@/components/delete-block-button";
// import { BlockVisibilityControls } from "@/components/block-visibility-controls";
// import { BlockJsonPanel } from "@/components/block-json-panel";

// type P = { id: string };

// async function updateSlugAction(formData: FormData) {
//   "use server";
//   const id = String(formData.get("id") ?? "");
//   const slug = String(formData.get("slug") ?? "").trim();

//   const token = (await cookies()).get("access_token")?.value;
//   if (!token) redirect("/admin/login");

//   const apiUrl = process.env.API_URL ?? "http://localhost:3000";
//   const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}`, {
//     method: "PATCH",
//     headers: {
//       Authorization: `Bearer ${token}`,
//       "content-type": "application/json",
//     },
//     body: JSON.stringify({ slug }),
//     cache: "no-store",
//   });

//   if (!r.ok) redirect(`/admin/pages/${id}?slugError=${r.status}`);

//   revalidatePath(`/admin/pages/${id}`);
//   revalidatePath(`/admin/pages`);
// }

// async function duplicateAction(formData: FormData) {
//   "use server";
//   const id = String(formData.get("id") ?? "");
//   const token = (await cookies()).get("access_token")?.value;
//   if (!token) redirect("/admin/login");

//   const apiUrl = process.env.API_URL ?? "http://localhost:3000";
//   const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/duplicate`, {
//     method: "POST",
//     headers: { Authorization: `Bearer ${token}` },
//     cache: "no-store",
//   });

//   if (!r.ok) redirect(`/admin/pages/${id}?dupError=${r.status}`);

//   const data = (await r.json()) as { page: { id: string } };
//   revalidatePath("/admin/pages");
//   redirect(`/admin/pages/${data.page.id}`);
// }

// async function moveBlockAction(formData: FormData) {
//   "use server";
//   const blockId = String(formData.get("blockId") ?? "");
//   const pageId = String(formData.get("pageId") ?? "");
//   const dir = String(formData.get("dir") ?? "") as "up" | "down";

//   const token = (await cookies()).get("access_token")?.value;
//   if (!token) return;

//   const apiUrl = process.env.API_URL ?? "http://localhost:3000";
//   await fetch(`${apiUrl}/v1/admin/blocks/${encodeURIComponent(blockId)}/move`, {
//     method: "POST",
//     headers: {
//       Authorization: `Bearer ${token}`,
//       "content-type": "application/json",
//     },
//     body: JSON.stringify({ direction: dir }),
//     cache: "no-store",
//   });

//   revalidatePath(`/admin/pages/${pageId}`);
// }

// async function publishAction(formData: FormData) {
//   "use server";
//   const id = String(formData.get("id") ?? "");
//   const token = (await cookies()).get("access_token")?.value;
//   if (!token) return;

//   const apiUrl = process.env.API_URL ?? "http://localhost:3000";
//   await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/publish`, {
//     method: "POST",
//     headers: { Authorization: `Bearer ${token}` },
//     cache: "no-store",
//   });

//   revalidatePath(`/admin/pages/${id}`);
// }

// async function unpublishAction(formData: FormData) {
//   "use server";
//   const id = String(formData.get("id") ?? "");
//   const token = (await cookies()).get("access_token")?.value;
//   if (!token) return;

//   const apiUrl = process.env.API_URL ?? "http://localhost:3000";
//   await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/unpublish`, {
//     method: "POST",
//     headers: { Authorization: `Bearer ${token}` },
//     cache: "no-store",
//   });

//   revalidatePath(`/admin/pages/${id}`);
// }

// function pickBlockId(sp: Record<string, string | string[]>) {
//   const v = sp["block"];
//   if (typeof v === "string") return v;
//   if (Array.isArray(v) && v.length) return v[0];
//   return "";
// }

// export default async function AdminPageDetails({
//   params,
//   searchParams,
// }: {
//   params: P | Promise<P>;
//   searchParams: Promise<Record<string, string | string[]>>;
// }) {
//   const p = await Promise.resolve(params);
//   const sp = await Promise.resolve(searchParams);

//   const { page } = await fetchAdminPage(p.id);

//   const blocks = Array.isArray(page.blocks) ? [...page.blocks] : [];
//   blocks.sort((a: any, b: any) => (a.order ?? 0) - (b.order ?? 0));

//   const selectedId = pickBlockId(sp);
//   const active =
//     blocks.find((b: any) => b.id === selectedId) ??
//     blocks[0] ??
//     null;

//   return (
//     <div className="space-y-6">
//       {/* Header */}
//       <div className="flex items-center justify-between gap-4">
//         <div className="space-y-1">
//           <div className="text-sm text-muted-foreground">
//             <Link className="underline" href="/admin/pages">
//               Pages
//             </Link>{" "}
//             / {page.slug}
//           </div>

//           <h1 className="text-2xl font-semibold">{page.slug}</h1>

//           <div className="flex items-center gap-2 text-sm text-muted-foreground">
//             <span>locale: {page.locale}</span>

//             <div className="flex items-center gap-2">
//               {page.status === "published" ? (
//                 <form action={unpublishAction}>
//                   <input type="hidden" name="id" value={page.id} />
//                   <Button type="submit" variant="secondary">
//                     Unpublish
//                   </Button>
//                 </form>
//               ) : (
//                 <form action={publishAction}>
//                   <input type="hidden" name="id" value={page.id} />
//                   <Button type="submit">Publish</Button>
//                 </form>
//               )}
//             </div>
//           </div>
//         </div>

//         <div className="flex items-center gap-2">
//           <Button asChild variant="secondary">
//             <Link href={`/api/preview/${page.id}`} target="_blank" rel="noreferrer">
//               Preview
//             </Link>
//           </Button>

//           <form action={duplicateAction}>
//             <input type="hidden" name="id" value={page.id} />
//             <Button type="submit" variant="secondary">
//               Duplicate
//             </Button>
//           </form>
//         </div>
//       </div>

//       {/* Page settings */}
//       <Card className="max-w-lg">
//         <CardHeader>
//           <CardTitle>Page settings</CardTitle>
//         </CardHeader>

//         <CardContent className="space-y-4">
//           {"slugError" in sp ? (
//             <div className="text-sm text-red-600">Slug update failed</div>
//           ) : null}

//           <form action={updateSlugAction} className="space-y-2">
//             <input type="hidden" name="id" value={page.id} />
//             <div className="text-sm font-medium">Slug</div>
//             <Input name="slug" defaultValue={page.slug} />
//             <div className="flex gap-2">
//               <Button type="submit">Save slug</Button>
//               <Button asChild variant="secondary">
//                 <Link href="/admin/pages">Back</Link>
//               </Button>
//             </div>
//           </form>

//           <div className="pt-2">
//             <Button asChild variant="destructive">
//               <Link href={`/admin/pages/${page.id}/delete`}>Delete page…</Link>
//             </Button>
//           </div>
//         </CardContent>
//       </Card>

//       {/* Meta */}
//       <div className="rounded-xl border p-4 space-y-2">
//         <div className="text-sm text-muted-foreground">
//           Updated: {new Date(page.updatedAt).toLocaleString()}
//         </div>
//         <div className="text-sm text-muted-foreground">
//           Blocks: {blocks.length}
//         </div>
//       </div>

//       {/* Blocks workspace (server-driven selection) */}
//       <div className="grid gap-4 md:grid-cols-[360px_1fr]">
//         {/* Left list */}
//         <div className="rounded-xl border p-4 space-y-4">
//           <div className="flex items-center justify-between">
//             <div className="font-semibold">Blocks</div>
//           </div>

//           <AddBlockForm pageId={page.id} />

//           <div className="space-y-3">
//             {blocks.map((b: any, i: number) => {
//               const isActive = active?.id === b.id;
//               const title = `#${b.order} ${b.type}:${b.variant}`;
//               const href = `/admin/pages/${page.id}?block=${encodeURIComponent(b.id)}`;

//               return (
//                 <div
//                   key={b.id}
//                   className={[
//                     "rounded-lg border p-3",
//                     isActive ? "border-primary/40 bg-muted/30" : "hover:bg-muted/20",
//                   ].join(" ")}
//                 >
//                   <Link href={href} className="block">
//                     <div className="font-medium">{title}</div>
//                     {b.data?._layout?.anchor ? (
//                       <div className="text-xs text-muted-foreground">
//                         anchor: {String(b.data._layout.anchor)}
//                       </div>
//                     ) : null}
//                   </Link>

//                   <div className="mt-2 flex flex-wrap items-center gap-2">
//                     <form action={moveBlockAction}>
//                       <input type="hidden" name="blockId" value={b.id} />
//                       <input type="hidden" name="pageId" value={page.id} />
//                       <input type="hidden" name="dir" value="up" />
//                       <Button size="sm" variant="secondary" type="submit" disabled={i === 0}>
//                         Up
//                       </Button>
//                     </form>

//                     <form action={moveBlockAction}>
//                       <input type="hidden" name="blockId" value={b.id} />
//                       <input type="hidden" name="pageId" value={page.id} />
//                       <input type="hidden" name="dir" value="down" />
//                       <Button
//                         size="sm"
//                         variant="secondary"
//                         type="submit"
//                         disabled={i === blocks.length - 1}
//                       >
//                         Down
//                       </Button>
//                     </form>

//                     <DeleteBlockButton blockId={b.id} />

//                     {/* ВАЖЛИВО: hide controls залишаємо тут */}
//                     <BlockVisibilityControls blockId={b.id} initial={b.data} />
//                   </div>
//                 </div>
//               );
//             })}
//           </div>
//         </div>

//         {/* Right editor */}
//         <div className="space-y-4">
//           {active ? (
//             <BlockJsonPanel
//               blockId={active.id}
//               title={`#${active.order} ${active.type}:${active.variant}`}
//               initial={active.data}
//             />
//           ) : (
//             <div className="rounded-xl border p-6 text-sm text-muted-foreground">
//               No blocks found.
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }
import Link from "next/link";
import { fetchAdminPage } from "@/lib/admin-api";
import { Button } from "@/components/ui/button";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { BlocksWorkspace } from "@/components/blocks-workspace";

type P = { id: string };

async function updateSlugAction(formData: FormData) {
  "use server";
  const id = String(formData.get("id") ?? "");
  const slug = String(formData.get("slug") ?? "").trim();

  const token = (await cookies()).get("access_token")?.value;
  if (!token) redirect("/admin/login");

  const apiUrl = process.env.API_URL ?? "http://localhost:3000";
  const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({ slug }),
    cache: "no-store",
  });

  if (!r.ok) redirect(`/admin/pages/${id}?slugError=${r.status}`);

  revalidatePath(`/admin/pages/${id}`);
  revalidatePath(`/admin/pages`);
}

async function duplicateAction(formData: FormData) {
  "use server";
  const id = String(formData.get("id") ?? "");
  const token = (await cookies()).get("access_token")?.value;
  if (!token) redirect("/admin/login");

  const apiUrl = process.env.API_URL ?? "http://localhost:3000";
  const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/duplicate`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });

  if (!r.ok) redirect(`/admin/pages/${id}?dupError=${r.status}`);

  const data = (await r.json()) as { page: { id: string } };
  revalidatePath("/admin/pages");
  redirect(`/admin/pages/${data.page.id}`);
}

async function publishAction(formData: FormData) {
  "use server";
  const id = String(formData.get("id") ?? "");
  const token = (await cookies()).get("access_token")?.value;
  if (!token) return;

  const apiUrl = process.env.API_URL ?? "http://localhost:3000";
  await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/publish`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });

  revalidatePath(`/admin/pages/${id}`);
}

async function unpublishAction(formData: FormData) {
  "use server";
  const id = String(formData.get("id") ?? "");
  const token = (await cookies()).get("access_token")?.value;
  if (!token) return;

  const apiUrl = process.env.API_URL ?? "http://localhost:3000";
  await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}/unpublish`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });

  revalidatePath(`/admin/pages/${id}`);
}

function pickBlockId(sp: Record<string, string | string[]>) {
  const v = sp["block"];
  if (typeof v === "string") return v;
  if (Array.isArray(v) && v.length) return v[0];
  return "";
}

export default async function AdminPageDetails({
  params,
  searchParams,
}: {
  params: P | Promise<P>;
  searchParams: Promise<Record<string, string | string[]>>;
}) {
  const p = await Promise.resolve(params);
  const sp = await Promise.resolve(searchParams);

  const { page } = await fetchAdminPage(p.id);

  const blocks = Array.isArray(page.blocks) ? [...page.blocks] : [];
  blocks.sort((a: any, b: any) => (a.order ?? 0) - (b.order ?? 0));

  const initialBlockId = pickBlockId(sp);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-sm text-muted-foreground">
            <Link className="underline" href="/admin/pages">
              Pages
            </Link>{" "}
            / {page.slug}
          </div>

          <h1 className="text-2xl font-semibold">{page.slug}</h1>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>locale: {page.locale}</span>

            <div className="flex items-center gap-2">
              {page.status === "published" ? (
                <form action={unpublishAction}>
                  <input type="hidden" name="id" value={page.id} />
                  <Button type="submit" variant="secondary">
                    Unpublish
                  </Button>
                </form>
              ) : (
                <form action={publishAction}>
                  <input type="hidden" name="id" value={page.id} />
                  <Button type="submit">Publish</Button>
                </form>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button asChild variant="secondary">
            <Link href={`/api/preview/${page.id}`} target="_blank" rel="noreferrer">
              Preview
            </Link>
          </Button>

          <form action={duplicateAction}>
            <input type="hidden" name="id" value={page.id} />
            <Button type="submit" variant="secondary">
              Duplicate
            </Button>
          </form>
        </div>
      </div>

      {/* Page settings */}
      <Card className="max-w-lg">
        <CardHeader>
          <CardTitle>Page settings</CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {"slugError" in sp ? (
            <div className="text-sm text-red-600">Slug update failed</div>
          ) : null}

          <form action={updateSlugAction} className="space-y-2">
            <input type="hidden" name="id" value={page.id} />
            <div className="text-sm font-medium">Slug</div>
            <Input name="slug" defaultValue={page.slug} />
            <div className="flex gap-2">
              <Button type="submit">Save slug</Button>
              <Button asChild variant="secondary">
                <Link href="/admin/pages">Back</Link>
              </Button>
            </div>
          </form>

          <div className="pt-2">
            <Button asChild variant="destructive">
              <Link href={`/admin/pages/${page.id}/delete`}>Delete page…</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Meta */}
      <div className="rounded-xl border p-4 space-y-2">
        <div className="text-sm text-muted-foreground">
          Updated: {new Date(page.updatedAt).toLocaleString()}
        </div>
        <div className="text-sm text-muted-foreground">Blocks: {blocks.length}</div>
      </div>

      {/* Workspace (КЛІКИ БЕЗ НАВІГАЦІЇ) */}
      <BlocksWorkspace
        pageId={page.id}
        blocks={blocks}
        initialActiveId={initialBlockId}
      />
    </div>
  );
}