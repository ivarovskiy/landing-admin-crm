import { cookies } from "next/headers"
import type { paths } from "@acme/openapi-client"

type AdminPages200 =
  NonNullable<paths["/v1/admin/pages"]["get"]["responses"]["200"]["content"]>["application/json"]

export async function fetchAdminPages(): Promise<AdminPages200> {
  const token = (await cookies()).get("access_token")?.value
  const apiUrl = process.env.API_URL ?? "http://localhost:3000"
  if (!token) throw new Error("No access token")

  const r = await fetch(`${apiUrl}/v1/admin/pages`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  })

  if (!r.ok) throw new Error(`Failed to load pages: ${r.status}`)
  return (await r.json()) as AdminPages200
}

type AdminPage200 =
  NonNullable<paths["/v1/admin/pages/{id}"]["get"]["responses"]["200"]["content"]>["application/json"]

export async function fetchAdminPage(id: string): Promise<AdminPage200> {
  const token = (await cookies()).get("access_token")?.value
  const apiUrl = process.env.API_URL ?? "http://localhost:3000"
  if (!token) throw new Error("No access token")

  const r = await fetch(`${apiUrl}/v1/admin/pages/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  })

  if (!r.ok) throw new Error(`Failed to load page: ${r.status}`)
  return (await r.json()) as AdminPage200
}
export async function createPreviewToken(pageId: string): Promise<{ token: string; expiresAt: string }> {
  const token = (await cookies()).get("access_token")?.value
  const apiUrl = process.env.API_URL ?? "http://localhost:3000"
  if (!token) throw new Error("No access token")

  const r = await fetch(`${apiUrl}/v1/admin/pages/${pageId}/preview-token`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  })

  if (!r.ok) throw new Error(`Failed to create preview token: ${r.status}`)
  return r.json()
}