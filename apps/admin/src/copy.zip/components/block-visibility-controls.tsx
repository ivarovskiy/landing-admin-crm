"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Smartphone, Monitor, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";

type Hide = { base?: boolean; md?: boolean; lg?: boolean };
type Layout = { hide?: Hide };
type BlockData = { _layout?: Layout; [k: string]: any };

function readHide(initial: any): Hide {
  const raw = initial?._layout?.hide;
  if (!raw || typeof raw !== "object") return {};
  return {
    base: raw.base === true,
    md: raw.md === true,
    lg: raw.lg === true,
  };
}

export function BlockVisibilityControls({
  blockId,
  initial,
}: {
  blockId: string;
  initial: any;
}) {
  const router = useRouter();
  const [hide, setHide] = useState<Hide>(() => readHide(initial));
  const [saving, setSaving] = useState<null | "mobile" | "desktop">(null);
  const [error, setError] = useState<string | null>(null);

  // Desktop = md + lg разом (>= md)
  const desktopState = useMemo(() => {
    const md = !!hide.md;
    const lg = !!hide.lg;
    if (!md && !lg) return "visible" as const;
    if (md && lg) return "hidden" as const;
    return "mixed" as const;
  }, [hide.md, hide.lg]);

  async function persist(nextHide: Hide) {
    const nextData: BlockData = { ...(initial ?? {}) };
    const nextLayout: Layout = { ...(nextData._layout ?? {}) };

    nextLayout.hide = { ...(nextLayout.hide ?? {}), ...nextHide };
    nextData._layout = nextLayout;

    const r = await fetch(`/api/admin/blocks/${blockId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ data: nextData }),
    });

    if (!r.ok) {
      const t = await r.text();
      throw new Error(t || `HTTP ${r.status}`);
    }
  }

  async function toggleMobile() {
    setError(null);
    const prev = hide;
    const next = { ...hide, base: !hide.base }; // Mobile = base (<md)

    setHide(next);
    setSaving("mobile");

    try {
      await persist(next);
      router.refresh();
    } catch (e: any) {
      setHide(prev);
      setError(e?.message ?? "Save failed");
    } finally {
      setSaving(null);
    }
  }

  async function toggleDesktop() {
    setError(null);
    const prev = hide;

    // Desktop = md + lg разом (>=md): visible/mixed -> hide; hidden -> show
    const shouldHide = desktopState !== "hidden";
    const next = { ...hide, md: shouldHide, lg: shouldHide };

    setHide(next);
    setSaving("desktop");

    try {
      await persist(next);
      router.refresh();
    } catch (e: any) {
      setHide(prev);
      setError(e?.message ?? "Save failed");
    } finally {
      setSaving(null);
    }
  }

  const mobileHidden = !!hide.base;
  const desktopHidden = desktopState === "hidden";
  const desktopMixed = desktopState === "mixed";

  return (
    <div className="flex items-center gap-1">
      <Button
        type="button"
        size="sm"
        variant={mobileHidden ? "outline" : "secondary"}
        onClick={toggleMobile}
        disabled={saving !== null}
        title={mobileHidden ? "Show on mobile (<md)" : "Hide on mobile (<md)"}
      >
        <Smartphone className="h-4 w-4" />
        <span className="ml-2 hidden md:inline">Mobile</span>
      </Button>

      <Button
        type="button"
        size="sm"
        variant={desktopHidden ? "outline" : "secondary"}
        onClick={toggleDesktop}
        disabled={saving !== null}
        title={
          desktopHidden
            ? "Show on desktop (≥md)"
            : "Hide on desktop (≥md)"
        }
      >
        {desktopMixed ? <Minus className="h-4 w-4" /> : <Monitor className="h-4 w-4" />}
        <span className="ml-2 hidden md:inline">Desktop</span>
      </Button>

      {error ? (
        <span className="ml-2 text-xs text-red-600 max-w-[260px] truncate">
          {error}
        </span>
      ) : null}
    </div>
  );
}