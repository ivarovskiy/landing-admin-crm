"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { BlockJsonPanel } from "@/components/block-json-panel";
import { getBlockForm } from "@/components/block-forms";

export function BlockEditPanel({
  blockId,
  title,
  type,
  variant,
  initial,
}: {
  blockId: string;
  title: string;
  type: string;
  variant: string;
  initial: any;
}) {
  const router = useRouter();
  const Form = useMemo(() => getBlockForm(type, variant), [type, variant]);

  const [mode, setMode] = useState<"form" | "json">(() => (Form ? "form" : "json"));
  const [draft, setDraft] = useState<any>(initial ?? {});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(initial ?? {});
    setError(null);
    setMode(Form ? "form" : "json");
  }, [blockId, Form, initial]);

  const dirty = JSON.stringify(draft ?? {}) !== JSON.stringify(initial ?? {});

  async function save() {
    setError(null);
    setSaving(true);
    try {
      const r = await fetch(`/api/admin/blocks/${blockId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ data: draft }),
      });
      if (!r.ok) throw new Error(await r.text());
      router.refresh();
    } catch (e: any) {
      setError(e?.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  }

  if (mode === "json" || !Form) {
    return (
      <div className="space-y-3">
        {Form ? (
          <div className="flex items-center justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => setMode("form")}>
              Form
            </Button>
            <Button type="button" onClick={() => setMode("json")}>
              JSON
            </Button>
          </div>
        ) : null}

        <BlockJsonPanel blockId={blockId} title={title} initial={initial} />
      </div>
    );
  }

  return (
    <div className="rounded-xl border p-4 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm text-muted-foreground">Editing</div>
          <div className="font-semibold">{title}</div>
          <div className="text-xs text-muted-foreground mt-1">
            Mode: <span className="font-mono">Form</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button type="button" onClick={() => setMode("json")} variant="secondary">
            JSON
          </Button>
        </div>
      </div>

      <Form value={draft} onChange={setDraft} />

      {error ? <div className="text-sm text-red-600 break-all">{error}</div> : null}

      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="secondary" disabled={!dirty || saving} onClick={() => setDraft(initial ?? {})}>
          Reset
        </Button>
        <Button type="button" disabled={!dirty || saving} onClick={save}>
          {saving ? "Saving..." : "Save"}
        </Button>
      </div>
    </div>
  );
}
