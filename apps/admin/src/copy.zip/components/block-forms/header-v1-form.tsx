"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { BlockFormProps } from "./index";

type LinkItem = { label?: string; href?: string };
type MenuItem = { label?: string; href?: string; children?: LinkItem[] };
type LogoSource =
  | { kind: "asset"; name?: string }
  | { kind: "url"; src?: string; alt?: string };

function arr<T = any>(v: any): T[] {
  return Array.isArray(v) ? (v as T[]) : [];
}
function setAt<T>(items: T[], idx: number, next: T) {
  const copy = items.slice();
  copy[idx] = next;
  return copy;
}
function removeAt<T>(items: T[], idx: number) {
  const copy = items.slice();
  copy.splice(idx, 1);
  return copy;
}

function normalizeLogo(v: any): LogoSource | undefined {
  if (!v || typeof v !== "object") return undefined;
  if (v.kind === "asset") return { kind: "asset", name: String(v.name ?? "") };
  if (v.kind === "url") return { kind: "url", src: String(v.src ?? ""), alt: String(v.alt ?? "") };
  // backward compat: якщо було name без kind
  if (typeof v.name === "string") return { kind: "asset", name: v.name };
  return undefined;
}

export function HeaderV1Form({ value, onChange }: BlockFormProps) {
  const brand = value?.brand ?? {};
  const links: LinkItem[] = arr<LinkItem>(value?.links);
  const cta = value?.cta ?? {};

  const mobile = value?.mobile ?? {};
  const top = mobile?.top ?? {};
  const masthead = mobile?.masthead ?? {};
  const portal = mobile?.portal ?? {};
  const menu: MenuItem[] = arr<MenuItem>(mobile?.menu);
  const promo = mobile?.promo ?? {};

  const mastheadLogo = normalizeLogo(masthead?.logo);
  const promoLogo = normalizeLogo(promo?.logo);

  return (
    <div className="space-y-6">
      {/* Desktop */}
      <div className="rounded-xl border p-4 space-y-4">
        <div className="font-semibold">Desktop</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">Brand label</div>
            <Input
              value={brand?.label ?? ""}
              onChange={(e) => onChange({ ...value, brand: { ...brand, label: e.target.value } })}
              placeholder="Ballet School"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Brand href</div>
            <Input
              value={brand?.href ?? ""}
              onChange={(e) => onChange({ ...value, brand: { ...brand, href: e.target.value } })}
              placeholder="#hero"
            />
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">CTA label</div>
            <Input
              value={cta?.label ?? ""}
              onChange={(e) => onChange({ ...value, cta: { ...cta, label: e.target.value } })}
              placeholder="Записатися"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">CTA href</div>
            <Input
              value={cta?.href ?? ""}
              onChange={(e) => onChange({ ...value, cta: { ...cta, href: e.target.value } })}
              placeholder="#address"
            />
          </div>
        </div>

        {/* Desktop links */}
        <div className="flex items-center justify-between">
          <div className="font-semibold">Links</div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => onChange({ ...value, links: [...links, { label: "", href: "" }] })}
          >
            Add link
          </Button>
        </div>

        <div className="space-y-2">
          {links.map((l, idx) => (
            <div key={idx} className="grid gap-2 md:grid-cols-[1fr_1fr_auto] items-end">
              <div>
                <div className="text-sm font-medium mb-1">Label</div>
                <Input
                  value={l?.label ?? ""}
                  onChange={(e) => onChange({ ...value, links: setAt(links, idx, { ...l, label: e.target.value }) })}
                  placeholder="About Us"
                />
              </div>
              <div>
                <div className="text-sm font-medium mb-1">Href</div>
                <Input
                  value={l?.href ?? ""}
                  onChange={(e) => onChange({ ...value, links: setAt(links, idx, { ...l, href: e.target.value }) })}
                  placeholder="#about"
                />
              </div>
              <Button type="button" variant="destructive" onClick={() => onChange({ ...value, links: removeAt(links, idx) })}>
                Remove
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Mobile */}
      <div className="rounded-xl border p-4 space-y-4">
        <div className="font-semibold">Mobile</div>

        {/* Top */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Top bar</div>
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Phone href</div>
              <Input
                value={top?.phoneHref ?? ""}
                onChange={(e) =>
                  onChange({ ...value, mobile: { ...mobile, top: { ...top, phoneHref: e.target.value } } })
                }
                placeholder="tel:+16108830878"
              />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Email href</div>
              <Input
                value={top?.emailHref ?? ""}
                onChange={(e) =>
                  onChange({ ...value, mobile: { ...mobile, top: { ...top, emailHref: e.target.value } } })
                }
                placeholder="mailto:simplydancepa@gmail.com"
              />
            </div>
          </div>
        </div>

        {/* Masthead */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Masthead</div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Sub text</div>
              <Input
                value={masthead?.subText ?? ""}
                onChange={(e) =>
                  onChange({ ...value, mobile: { ...mobile, masthead: { ...masthead, subText: e.target.value } } })
                }
                placeholder="PRE-PROFESSIONAL"
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Logo kind</div>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={mastheadLogo?.kind ?? "asset"}
                onChange={(e) => {
                  const kind = e.target.value as "asset" | "url";
                  const nextLogo: LogoSource = kind === "asset" ? { kind: "asset", name: "" } : { kind: "url", src: "", alt: "" };
                  onChange({
                    ...value,
                    mobile: { ...mobile, masthead: { ...masthead, logo: nextLogo } },
                  });
                }}
              >
                <option value="asset">asset</option>
                <option value="url">url</option>
              </select>
            </div>
          </div>

          {mastheadLogo?.kind === "asset" ? (
            <div>
              <div className="text-sm font-medium mb-1">Logo asset name</div>
              <Input
                value={mastheadLogo?.name ?? ""}
                onChange={(e) =>
                  onChange({
                    ...value,
                    mobile: {
                      ...mobile,
                      masthead: { ...masthead, logo: { kind: "asset", name: e.target.value } },
                    },
                  })
                }
                placeholder="ibc-ballet-pre"
              />
            </div>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-sm font-medium mb-1">Logo URL</div>
                <Input
                  value={(mastheadLogo as any)?.src ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      mobile: {
                        ...mobile,
                        masthead: { ...masthead, logo: { kind: "url", src: e.target.value, alt: (mastheadLogo as any)?.alt ?? "" } },
                      },
                    })
                  }
                  placeholder="https://..."
                />
              </div>
              <div>
                <div className="text-sm font-medium mb-1">Alt</div>
                <Input
                  value={(mastheadLogo as any)?.alt ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      mobile: {
                        ...mobile,
                        masthead: { ...masthead, logo: { kind: "url", src: (mastheadLogo as any)?.src ?? "", alt: e.target.value } },
                      },
                    })
                  }
                  placeholder="Logo"
                />
              </div>
            </div>
          )}

          <div>
            <div className="text-sm font-medium mb-1">Tagline</div>
            <Textarea
              value={masthead?.tagline ?? ""}
              onChange={(e) =>
                onChange({ ...value, mobile: { ...mobile, masthead: { ...masthead, tagline: e.target.value } } })
              }
              className="min-h-[120px]"
              placeholder={"ENHANCE\nYOUR TECHNIQUE,\nGET\nPERSONALIZED ATTENTION\nAND\nSHINE ON STAGE"}
            />
            <div className="text-xs text-muted-foreground mt-1">New line = перенос рядка</div>
          </div>
        </div>

        {/* Portal */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Portal</div>
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Label</div>
              <Input
                value={portal?.label ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, portal: { ...portal, label: e.target.value } } })}
                placeholder="Parent Portal"
              />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Href</div>
              <Input
                value={portal?.href ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, portal: { ...portal, href: e.target.value } } })}
                placeholder="#"
              />
            </div>
          </div>
        </div>

        {/* Menu */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="flex items-center justify-between">
            <div className="font-semibold">Menu</div>
            <Button
              type="button"
              variant="secondary"
              onClick={() =>
                onChange({
                  ...value,
                  mobile: { ...mobile, menu: [...menu, { label: "", href: "", children: [] }] },
                })
              }
            >
              Add item
            </Button>
          </div>

          <div className="space-y-3">
            {menu.map((m, idx) => {
              const children = arr<LinkItem>(m?.children);

              return (
                <div key={idx} className="rounded-xl border p-3 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-medium">Item {idx + 1}</div>
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => onChange({ ...value, mobile: { ...mobile, menu: removeAt(menu, idx) } })}
                    >
                      Remove
                    </Button>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <div className="text-sm font-medium mb-1">Label</div>
                      <Input
                        value={m?.label ?? ""}
                        onChange={(e) =>
                          onChange({
                            ...value,
                            mobile: {
                              ...mobile,
                              menu: setAt(menu, idx, { ...m, label: e.target.value }),
                            },
                          })
                        }
                        placeholder="ABOUT US"
                      />
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">Href</div>
                      <Input
                        value={m?.href ?? ""}
                        onChange={(e) =>
                          onChange({
                            ...value,
                            mobile: {
                              ...mobile,
                              menu: setAt(menu, idx, { ...m, href: e.target.value }),
                            },
                          })
                        }
                        placeholder="#about"
                      />
                    </div>
                  </div>

                  {/* Children */}
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">Children</div>
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() =>
                        onChange({
                          ...value,
                          mobile: {
                            ...mobile,
                            menu: setAt(menu, idx, { ...m, children: [...children, { label: "", href: "" }] }),
                          },
                        })
                      }
                    >
                      Add child
                    </Button>
                  </div>

                  {children.length ? (
                    <div className="space-y-2">
                      {children.map((c, cIdx) => (
                        <div key={cIdx} className="grid gap-2 md:grid-cols-[1fr_1fr_auto] items-end">
                          <div>
                            <div className="text-sm font-medium mb-1">Label</div>
                            <Input
                              value={c?.label ?? ""}
                              onChange={(e) => {
                                const nextChildren = setAt(children, cIdx, { ...c, label: e.target.value });
                                onChange({
                                  ...value,
                                  mobile: { ...mobile, menu: setAt(menu, idx, { ...m, children: nextChildren }) },
                                });
                              }}
                            />
                          </div>
                          <div>
                            <div className="text-sm font-medium mb-1">Href</div>
                            <Input
                              value={c?.href ?? ""}
                              onChange={(e) => {
                                const nextChildren = setAt(children, cIdx, { ...c, href: e.target.value });
                                onChange({
                                  ...value,
                                  mobile: { ...mobile, menu: setAt(menu, idx, { ...m, children: nextChildren }) },
                                });
                              }}
                            />
                          </div>
                          <Button
                            type="button"
                            variant="destructive"
                            onClick={() => {
                              const nextChildren = removeAt(children, cIdx);
                              onChange({
                                ...value,
                                mobile: { ...mobile, menu: setAt(menu, idx, { ...m, children: nextChildren }) },
                              });
                            }}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">No children</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Promo */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Promo</div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Label</div>
              <Input
                value={promo?.label ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, promo: { ...promo, label: e.target.value } } })}
                placeholder="CHECK OUT"
              />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Label 2</div>
              <Input
                value={promo?.label2 ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, promo: { ...promo, label2: e.target.value } } })}
                placeholder="OUR"
              />
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Logo text (fallback)</div>
              <Input
                value={promo?.logoText ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, promo: { ...promo, logoText: e.target.value } } })}
                placeholder="SIMPLY DANCE"
              />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Sub text</div>
              <Input
                value={promo?.subText ?? ""}
                onChange={(e) => onChange({ ...value, mobile: { ...mobile, promo: { ...promo, subText: e.target.value } } })}
                placeholder="CHILDREN’S PROGRAMS"
              />
            </div>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Href</div>
            <Input
              value={promo?.href ?? ""}
              onChange={(e) => onChange({ ...value, mobile: { ...mobile, promo: { ...promo, href: e.target.value } } })}
              placeholder="#"
            />
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Promo logo kind</div>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={promoLogo?.kind ?? "asset"}
                onChange={(e) => {
                  const kind = e.target.value as "asset" | "url";
                  const nextLogo: LogoSource = kind === "asset" ? { kind: "asset", name: "" } : { kind: "url", src: "", alt: "" };
                  onChange({
                    ...value,
                    mobile: { ...mobile, promo: { ...promo, logo: nextLogo } },
                  });
                }}
              >
                <option value="asset">asset</option>
                <option value="url">url</option>
              </select>
            </div>

            {promoLogo?.kind === "asset" ? (
              <div>
                <div className="text-sm font-medium mb-1">Promo logo asset name</div>
                <Input
                  value={(promoLogo as any)?.name ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      mobile: { ...mobile, promo: { ...promo, logo: { kind: "asset", name: e.target.value } } },
                    })
                  }
                  placeholder="simply-dance"
                />
              </div>
            ) : (
              <div>
                <div className="text-sm font-medium mb-1">Promo logo URL</div>
                <Input
                  value={(promoLogo as any)?.src ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      mobile: {
                        ...mobile,
                        promo: { ...promo, logo: { kind: "url", src: e.target.value, alt: (promoLogo as any)?.alt ?? "" } },
                      },
                    })
                  }
                  placeholder="https://..."
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
