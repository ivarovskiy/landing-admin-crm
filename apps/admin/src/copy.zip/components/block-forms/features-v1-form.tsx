"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { BlockFormProps } from "./index";

type Hide = { base?: boolean; md?: boolean; lg?: boolean };

function ensureItems(v: any) {
  return Array.isArray(v?.items) ? v.items : [];
}

function setItem(items: any[], idx: number, next: any) {
  const copy = items.slice();
  copy[idx] = next;
  return copy;
}

function removeItem(items: any[], idx: number) {
  const copy = items.slice();
  copy.splice(idx, 1);
  return copy;
}

function addItem(items: any[]) {
  return [
    ...items,
    {
      title: "FEATURE TITLE",
      text: "",
      icon: "ballet-bar",
      _layout: { hide: {} },
    },
  ];
}

function toggleHideMobile(hide: Hide) {
  return { ...hide, base: !hide.base };
}

// Desktop = >= md => md + lg разом
function toggleHideDesktop(hide: Hide) {
  const currentlyHidden = hide.md === true && hide.lg === true;
  const next = !currentlyHidden;
  return { ...hide, md: next, lg: next };
}

const ICONS = [
  { value: "ballet-bar", label: "Ballet bar" },
  { value: "ballet-shoes", label: "Ballet shoes" },
  { value: "prize-cup", label: "Prize cup" },
];

export function FeaturesV1Form({ value, onChange }: BlockFormProps) {
  const items = ensureItems(value);

  return (
    <div className="space-y-4">
      {/* Section fields */}
      <div className="grid gap-3">
        <div>
          <div className="text-sm font-medium mb-1">Title</div>
          <Input
            value={value?.title ?? ""}
            onChange={(e) => onChange({ ...value, title: e.target.value })}
            placeholder="OUR SCHOOL"
          />
        </div>

        <div>
          <div className="text-sm font-medium mb-1">Subtitle</div>
          <Input
            value={value?.subtitle ?? ""}
            onChange={(e) => onChange({ ...value, subtitle: e.target.value })}
            placeholder="junior company auditions"
          />
        </div>
      </div>

      {/* Items */}
      <div className="flex items-center justify-between">
        <div className="font-semibold">Items</div>
        <Button type="button" variant="secondary" onClick={() => onChange({ ...value, items: addItem(items) })}>
          Add item
        </Button>
      </div>

      <div className="space-y-3">
        {items.map((it: any, idx: number) => {
          const hide: Hide = it?._layout?.hide ?? {};
          const mobileHidden = hide.base === true;
          const desktopHidden = hide.md === true && hide.lg === true;

          return (
            <div key={idx} className="rounded-xl border p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="font-medium">Item {idx + 1}</div>
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  onClick={() => onChange({ ...value, items: removeItem(items, idx) })}
                >
                  Remove
                </Button>
              </div>

              <div className="grid gap-3">
                <div>
                  <div className="text-sm font-medium mb-1">Item title</div>
                  <Input
                    value={it?.title ?? ""}
                    onChange={(e) =>
                      onChange({
                        ...value,
                        items: setItem(items, idx, { ...it, title: e.target.value }),
                      })
                    }
                    placeholder={"BRAND NEW\nFACILITY"}
                  />
                  <div className="text-xs text-muted-foreground mt-1">Use \\n for new lines</div>
                </div>

                <div>
                  <div className="text-sm font-medium mb-1">Text</div>
                  <Textarea
                    value={it?.text ?? ""}
                    onChange={(e) =>
                      onChange({
                        ...value,
                        items: setItem(items, idx, { ...it, text: e.target.value }),
                      })
                    }
                    className="min-h-[90px]"
                    placeholder="Description…"
                  />
                </div>

                <div>
                  <div className="text-sm font-medium mb-1">Icon</div>
                  <select
                    className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                    value={it?.icon ?? "ballet-bar"}
                    onChange={(e) =>
                      onChange({
                        ...value,
                        items: setItem(items, idx, { ...it, icon: e.target.value }),
                      })
                    }
                  >
                    {ICONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <Button
                    type="button"
                    size="sm"
                    variant={mobileHidden ? "outline" : "secondary"}
                    onClick={() => {
                      const nextHide = toggleHideMobile(hide);
                      const nextItem = { ...it, _layout: { ...(it?._layout ?? {}), hide: nextHide } };
                      onChange({ ...value, items: setItem(items, idx, nextItem) });
                    }}
                  >
                    Mobile {mobileHidden ? "Hidden" : "Visible"}
                  </Button>

                  <Button
                    type="button"
                    size="sm"
                    variant={desktopHidden ? "outline" : "secondary"}
                    onClick={() => {
                      const nextHide = toggleHideDesktop(hide);
                      const nextItem = { ...it, _layout: { ...(it?._layout ?? {}), hide: nextHide } };
                      onChange({ ...value, items: setItem(items, idx, nextItem) });
                    }}
                  >
                    Desktop {desktopHidden ? "Hidden" : "Visible"}
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
