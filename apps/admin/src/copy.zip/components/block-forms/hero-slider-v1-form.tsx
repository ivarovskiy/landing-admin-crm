"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { BlockFormProps } from "./index";

type Slide = {
  id?: string;
  title?: string;
  subtitle?: string;
  cta?: { label?: string; href?: string };
  media?: { kind?: "image"; src?: string; alt?: string };
  layout?: {
    desktop?: { imageSide?: "left" | "right" };
    mobile?: { imageFirst?: boolean };

    // reserved for future
    contentJustify?: "start" | "center" | "end";
    titleVariant?: string;
  };
};

function arr<T = any>(v: any): T[] {
  return Array.isArray(v) ? (v as T[]) : [];
}
function setAt<T>(items: T[], idx: number, next: T) {
  const copy = items.slice();
  copy[idx] = next;
  return copy;
}
function removeAt<T>(items: T[], idx: number) {
  const copy = items.slice();
  copy.splice(idx, 1);
  return copy;
}
function moveAt<T>(items: T[], idx: number, dir: "up" | "down") {
  const copy = items.slice();
  const j = dir === "up" ? idx - 1 : idx + 1;
  if (j < 0 || j >= copy.length) return copy;
  const tmp = copy[idx];
  copy[idx] = copy[j];
  copy[j] = tmp;
  return copy;
}

function newSlide(): Slide {
  return {
    id: crypto?.randomUUID?.() ?? `slide-${Date.now()}`,
    title: "SCHOOL YEAR\n2025–26",
    subtitle: "REGISTRATION NOW OPEN",
    cta: { label: "LEARN MORE", href: "#address" },
    media: { kind: "image", src: "https://placehold.co/900x900/png", alt: "Ballet" },
    layout: {
      desktop: { imageSide: "right" },
      mobile: { imageFirst: false },

      // reserved for future
      contentJustify: "center",
      titleVariant: "outline", // placeholder
    },
  };
}

export function HeroSliderV1Form({ value, onChange }: BlockFormProps) {
  const slides: Slide[] = arr<Slide>(value?.slides);
  const options = value?.options ?? {};

  const showDots = options?.showDots !== false;
  const showArrows = options?.showArrows === true;
  const autoPlayMs = Number(options?.autoPlayMs ?? 0);

  return (
    <div className="space-y-6">
      {/* Options */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="font-semibold">Options</div>

        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <div className="text-sm font-medium mb-1">Autoplay (ms)</div>
            <Input
              type="number"
              value={Number.isFinite(autoPlayMs) ? autoPlayMs : 0}
              onChange={(e) =>
                onChange({
                  ...value,
                  options: { ...options, autoPlayMs: Number(e.target.value || 0) },
                })
              }
              placeholder="0"
            />
            <div className="text-xs text-muted-foreground mt-1">0 = off, мінімум 1500</div>
          </div>

          <div className="flex flex-col justify-end gap-2">
            <Button
              type="button"
              variant={showDots ? "secondary" : "outline"}
              onClick={() => onChange({ ...value, options: { ...options, showDots: !showDots } })}
            >
              Dots: {showDots ? "On" : "Off"}
            </Button>
          </div>

          <div className="flex flex-col justify-end gap-2">
            <Button
              type="button"
              variant={showArrows ? "secondary" : "outline"}
              onClick={() => onChange({ ...value, options: { ...options, showArrows: !showArrows } })}
            >
              Arrows: {showArrows ? "On" : "Off"}
            </Button>
          </div>
        </div>
      </div>

      {/* Slides */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Slides</div>
          <Button type="button" variant="secondary" onClick={() => onChange({ ...value, slides: [...slides, newSlide()] })}>
            Add slide
          </Button>
        </div>

        <div className="space-y-4">
          {slides.map((s, idx) => {
            const cta = s?.cta ?? {};
            const media = s?.media ?? {};
            const layout = s?.layout ?? {};
            const desktop = layout?.desktop ?? {};
            const mobile = layout?.mobile ?? {};

            return (
              <div key={s?.id ?? idx} className="rounded-xl border p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-medium">Slide {idx + 1}</div>

                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={idx === 0}
                      onClick={() => onChange({ ...value, slides: moveAt(slides, idx, "up") })}
                    >
                      Up
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={idx === slides.length - 1}
                      onClick={() => onChange({ ...value, slides: moveAt(slides, idx, "down") })}
                    >
                      Down
                    </Button>
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => onChange({ ...value, slides: removeAt(slides, idx) })}
                    >
                      Remove
                    </Button>
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-sm font-medium mb-1">ID</div>
                    <Input
                      value={s?.id ?? ""}
                      onChange={(e) => onChange({ ...value, slides: setAt(slides, idx, { ...s, id: e.target.value }) })}
                      placeholder="school-year"
                    />
                  </div>

                  <div>
                    <div className="text-sm font-medium mb-1">Image side (desktop)</div>
                    <select
                      className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                      value={desktop?.imageSide ?? "right"}
                      onChange={(e) =>
                        onChange({
                          ...value,
                          slides: setAt(slides, idx, {
                            ...s,
                            layout: { ...layout, desktop: { ...desktop, imageSide: e.target.value as any } },
                          }),
                        })
                      }
                    >
                      <option value="right">Right</option>
                      <option value="left">Left</option>
                    </select>
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-sm font-medium mb-1">Title</div>
                    <Textarea
                      value={s?.title ?? ""}
                      onChange={(e) => onChange({ ...value, slides: setAt(slides, idx, { ...s, title: e.target.value }) })}
                      className="min-h-[90px]"
                      placeholder={"SCHOOL YEAR\n2025–26"}
                    />
                  </div>

                  <div>
                    <div className="text-sm font-medium mb-1">Subtitle</div>
                    <Textarea
                      value={s?.subtitle ?? ""}
                      onChange={(e) => onChange({ ...value, slides: setAt(slides, idx, { ...s, subtitle: e.target.value }) })}
                      className="min-h-[90px]"
                      placeholder={"REGISTRATION NOW OPEN"}
                    />
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-sm font-medium mb-1">CTA label</div>
                    <Input
                      value={cta?.label ?? ""}
                      onChange={(e) =>
                        onChange({
                          ...value,
                          slides: setAt(slides, idx, { ...s, cta: { ...cta, label: e.target.value } }),
                        })
                      }
                      placeholder="LEARN MORE"
                    />
                  </div>

                  <div>
                    <div className="text-sm font-medium mb-1">CTA href</div>
                    <Input
                      value={cta?.href ?? ""}
                      onChange={(e) =>
                        onChange({
                          ...value,
                          slides: setAt(slides, idx, { ...s, cta: { ...cta, href: e.target.value } }),
                        })
                      }
                      placeholder="#address"
                    />
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-sm font-medium mb-1">Image URL</div>
                    <Input
                      value={media?.src ?? ""}
                      onChange={(e) =>
                        onChange({
                          ...value,
                          slides: setAt(slides, idx, {
                            ...s,
                            media: { ...media, kind: "image", src: e.target.value },
                          }),
                        })
                      }
                      placeholder="https://..."
                    />
                  </div>
                  <div>
                    <div className="text-sm font-medium mb-1">Alt</div>
                    <Input
                      value={media?.alt ?? ""}
                      onChange={(e) =>
                        onChange({
                          ...value,
                          slides: setAt(slides, idx, {
                            ...s,
                            media: { ...media, kind: "image", alt: e.target.value },
                          }),
                        })
                      }
                      placeholder="Ballet"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    variant={mobile?.imageFirst ? "secondary" : "outline"}
                    onClick={() =>
                      onChange({
                        ...value,
                        slides: setAt(slides, idx, {
                          ...s,
                          layout: { ...layout, mobile: { ...mobile, imageFirst: !mobile?.imageFirst } },
                        }),
                      })
                    }
                  >
                    Mobile image first: {mobile?.imageFirst ? "Yes" : "No"}
                  </Button>

                  {/* placeholders for future */}
                  <Button type="button" variant="ghost" disabled title="Coming soon">
                    Content justify (coming soon)
                  </Button>
                  <Button type="button" variant="ghost" disabled title="Coming soon">
                    Title variant (coming soon)
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
