import type { ComponentType } from "react";
import { FeaturesV1Form } from "./features-v1-form";
import { StudioAddressV1Form } from "./studio-address-v1-form";
import { HeaderV1Form } from "./header-v1-form";
import { HeroSliderV1Form } from "./hero-slider-v1-form";
import { FooterV1Form } from "./footer-v1-form";

export type BlockFormProps = {
  value: any;
  onChange: (next: any) => void;
};

const REGISTRY: Record<string, ComponentType<BlockFormProps>> = {
  "features:v1": FeaturesV1Form,
  "studio-address:v1": StudioAddressV1Form,
  "header:v1": HeaderV1Form,
  "hero:slider-v1": HeroSliderV1Form,
  "footer:v1": FooterV1Form,
};

export function getBlockForm(type: string, variant: string) {
  return REGISTRY[`${type}:${variant}`];
}
