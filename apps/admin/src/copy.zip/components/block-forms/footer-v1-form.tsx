"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { BlockFormProps } from "./index";

type Link = { label?: string; href?: string };
type Column = { links?: Link[] };

type LogoSource =
  | { kind: "asset"; name?: string }
  | { kind: "url"; src?: string; alt?: string };

function arr<T = any>(v: any): T[] {
  return Array.isArray(v) ? (v as T[]) : [];
}
function setAt<T>(items: T[], idx: number, next: T) {
  const copy = items.slice();
  copy[idx] = next;
  return copy;
}
function removeAt<T>(items: T[], idx: number) {
  const copy = items.slice();
  copy.splice(idx, 1);
  return copy;
}
function normalizeLogo(v: any): LogoSource | undefined {
  if (!v || typeof v !== "object") return undefined;
  if (v.kind === "asset") return { kind: "asset", name: String(v.name ?? "") };
  if (v.kind === "url") return { kind: "url", src: String(v.src ?? ""), alt: String(v.alt ?? "") };
  if (typeof v.name === "string") return { kind: "asset", name: v.name };
  if (typeof v.src === "string") return { kind: "url", src: v.src, alt: String(v.alt ?? "") };
  return undefined;
}

export function FooterV1Form({ value, onChange }: BlockFormProps) {
  const left = value?.left ?? {};
  const right = value?.right ?? {};
  const portal = right?.portal ?? {};
  const promo = right?.promo ?? {};

  const columns: Column[] = arr<Column>(value?.columns);
  const bottomText: string = value?.bottomText ?? "";

  const leftLogo = normalizeLogo(left?.logo);
  const promoLogo = normalizeLogo(promo?.logo);

  return (
    <div className="space-y-6">
      {/* LEFT / BRAND */}
      <div className="rounded-xl border p-4 space-y-4">
        <div className="font-semibold">Left (Brand)</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">Href</div>
            <Input
              value={left?.href ?? ""}
              onChange={(e) => onChange({ ...value, left: { ...left, href: e.target.value } })}
              placeholder="#top"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Logo kind</div>
            <select
              className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={leftLogo?.kind ?? "asset"}
              onChange={(e) => {
                const kind = e.target.value as "asset" | "url";
                const nextLogo: LogoSource =
                  kind === "asset" ? { kind: "asset", name: "" } : { kind: "url", src: "", alt: "" };
                onChange({ ...value, left: { ...left, logo: nextLogo } });
              }}
            >
              <option value="asset">asset</option>
              <option value="url">url</option>
            </select>
          </div>
        </div>

        {leftLogo?.kind === "asset" ? (
          <div>
            <div className="text-sm font-medium mb-1">Logo asset name</div>
            <Input
              value={leftLogo?.name ?? ""}
              onChange={(e) => onChange({ ...value, left: { ...left, logo: { kind: "asset", name: e.target.value } } })}
              placeholder="ibc-ballet"
            />
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Logo URL</div>
              <Input
                value={(leftLogo as any)?.src ?? ""}
                onChange={(e) =>
                  onChange({
                    ...value,
                    left: { ...left, logo: { kind: "url", src: e.target.value, alt: (leftLogo as any)?.alt ?? "" } },
                  })
                }
                placeholder="https://..."
              />
            </div>
            <div>
              <div className="text-sm font-medium mb-1">Alt</div>
              <Input
                value={(leftLogo as any)?.alt ?? ""}
                onChange={(e) =>
                  onChange({
                    ...value,
                    left: { ...left, logo: { kind: "url", src: (leftLogo as any)?.src ?? "", alt: e.target.value } },
                  })
                }
                placeholder="IBC Ballet"
              />
            </div>
          </div>
        )}

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">Logo text (fallback)</div>
            <Input
              value={left?.logoText ?? ""}
              onChange={(e) => onChange({ ...value, left: { ...left, logoText: e.target.value } })}
              placeholder="IBC BALLET"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Sub text (fallback)</div>
            <Input
              value={left?.subText ?? ""}
              onChange={(e) => onChange({ ...value, left: { ...left, subText: e.target.value } })}
              placeholder="PRE-PROFESSIONAL"
            />
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          Якщо логотип SVG уже містить підпис — fallback поля можуть не використовуватись у web.
        </div>
      </div>

      {/* LINKS / COLUMNS */}
      <div className="rounded-xl border p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Links (Columns)</div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => onChange({ ...value, columns: [...columns, { links: [{ label: "", href: "" }] }] })}
          >
            Add column
          </Button>
        </div>

        <div className="space-y-4">
          {columns.map((col, colIdx) => {
            const links: Link[] = arr<Link>(col?.links);

            return (
              <div key={colIdx} className="rounded-xl border p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-medium">Column {colIdx + 1}</div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => onChange({ ...value, columns: removeAt(columns, colIdx) })}
                  >
                    Remove column
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">Links</div>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      const nextLinks = [...links, { label: "", href: "" }];
                      const nextCol = { ...col, links: nextLinks };
                      onChange({ ...value, columns: setAt(columns, colIdx, nextCol) });
                    }}
                  >
                    Add link
                  </Button>
                </div>

                <div className="space-y-2">
                  {links.map((l, linkIdx) => (
                    <div key={linkIdx} className="grid gap-2 md:grid-cols-[1fr_1fr_auto] items-end">
                      <div>
                        <div className="text-sm font-medium mb-1">Label</div>
                        <Input
                          value={l?.label ?? ""}
                          onChange={(e) => {
                            const nextLinks = setAt(links, linkIdx, { ...l, label: e.target.value });
                            const nextCol = { ...col, links: nextLinks };
                            onChange({ ...value, columns: setAt(columns, colIdx, nextCol) });
                          }}
                          placeholder="About Us"
                        />
                      </div>

                      <div>
                        <div className="text-sm font-medium mb-1">Href</div>
                        <Input
                          value={l?.href ?? ""}
                          onChange={(e) => {
                            const nextLinks = setAt(links, linkIdx, { ...l, href: e.target.value });
                            const nextCol = { ...col, links: nextLinks };
                            onChange({ ...value, columns: setAt(columns, colIdx, nextCol) });
                          }}
                          placeholder="#about"
                        />
                      </div>

                      <Button
                        type="button"
                        variant="destructive"
                        onClick={() => {
                          const nextLinks = removeAt(links, linkIdx);
                          const nextCol = { ...col, links: nextLinks };
                          onChange({ ...value, columns: setAt(columns, colIdx, nextCol) });
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {!columns.length ? (
            <div className="text-sm text-muted-foreground">No columns yet. Add one.</div>
          ) : null}
        </div>
      </div>

      {/* RIGHT / PORTAL + PROMO */}
      <div className="rounded-xl border p-4 space-y-4">
        <div className="font-semibold">Right (Portal + Promo)</div>

        {/* Portal */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Portal</div>

          <div className="grid gap-3 md:grid-cols-3">
            <div>
              <div className="text-sm font-medium mb-1">Label</div>
              <Input
                value={portal?.label ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, portal: { ...portal, label: e.target.value } } })}
                placeholder="Parent Portal"
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Href</div>
              <Input
                value={portal?.href ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, portal: { ...portal, href: e.target.value } } })}
                placeholder="#"
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Icon</div>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={portal?.icon ?? "lock"}
                onChange={(e) => onChange({ ...value, right: { ...right, portal: { ...portal, icon: e.target.value } } })}
              >
                <option value="lock">lock</option>
                <option value="unlock">unlock</option>
              </select>
            </div>
          </div>
        </div>

        {/* Promo */}
        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-semibold">Promo</div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Label</div>
              <Input
                value={promo?.label ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, promo: { ...promo, label: e.target.value } } })}
                placeholder="Check Out Our Children's Website"
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Href</div>
              <Input
                value={promo?.href ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, promo: { ...promo, href: e.target.value } } })}
                placeholder="#"
              />
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Logo kind</div>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={promoLogo?.kind ?? "asset"}
                onChange={(e) => {
                  const kind = e.target.value as "asset" | "url";
                  const nextLogo: LogoSource =
                    kind === "asset" ? { kind: "asset", name: "" } : { kind: "url", src: "", alt: "" };
                  onChange({ ...value, right: { ...right, promo: { ...promo, logo: nextLogo } } });
                }}
              >
                <option value="asset">asset</option>
                <option value="url">url</option>
              </select>
            </div>

            {promoLogo?.kind === "asset" ? (
              <div>
                <div className="text-sm font-medium mb-1">Logo asset name</div>
                <Input
                  value={(promoLogo as any)?.name ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      right: { ...right, promo: { ...promo, logo: { kind: "asset", name: e.target.value } } },
                    })
                  }
                  placeholder="simply-dance"
                />
              </div>
            ) : (
              <div>
                <div className="text-sm font-medium mb-1">Logo URL</div>
                <Input
                  value={(promoLogo as any)?.src ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...value,
                      right: { ...right, promo: { ...promo, logo: { kind: "url", src: e.target.value, alt: (promoLogo as any)?.alt ?? "" } } },
                    })
                  }
                  placeholder="https://..."
                />
              </div>
            )}
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-sm font-medium mb-1">Logo text (fallback)</div>
              <Input
                value={promo?.logoText ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, promo: { ...promo, logoText: e.target.value } } })}
                placeholder="SIMPLY DANCE STUDIO"
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Sub text (fallback)</div>
              <Input
                value={promo?.subText ?? ""}
                onChange={(e) => onChange({ ...value, right: { ...right, promo: { ...promo, subText: e.target.value } } })}
                placeholder="CHILDREN'S PROGRAMS"
              />
            </div>
          </div>

          {promoLogo?.kind === "url" ? (
            <div>
              <div className="text-sm font-medium mb-1">Alt</div>
              <Input
                value={(promoLogo as any)?.alt ?? ""}
                onChange={(e) =>
                  onChange({
                    ...value,
                    right: { ...right, promo: { ...promo, logo: { kind: "url", src: (promoLogo as any)?.src ?? "", alt: e.target.value } } },
                  })
                }
                placeholder="Simply Dance Studio"
              />
            </div>
          ) : null}
        </div>
      </div>

      {/* Bottom text */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="font-semibold">Bottom text</div>
        <Textarea
          value={bottomText}
          onChange={(e) => onChange({ ...value, bottomText: e.target.value })}
          className="min-h-[80px]"
          placeholder={"Copyright © 2024 Simply Dance Studio • All Rights Reserved"}
        />
        <div className="text-xs text-muted-foreground">Підтримує перенос рядків.</div>
      </div>
    </div>
  );
}
