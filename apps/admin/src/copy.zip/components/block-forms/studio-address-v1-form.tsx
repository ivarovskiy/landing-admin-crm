"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { BlockFormProps } from "./index";

type Social = { icon?: "instagram" | "facebook"; href?: string; label?: string };

function arr(v: any): any[] {
  return Array.isArray(v) ? v : [];
}

function setAt<T>(items: T[], idx: number, next: T) {
  const copy = items.slice();
  copy[idx] = next;
  return copy;
}

function removeAt<T>(items: T[], idx: number) {
  const copy = items.slice();
  copy.splice(idx, 1);
  return copy;
}

export function StudioAddressV1Form({ value, onChange }: BlockFormProps) {
  const addressLines: string[] = arr(value?.addressLines) as any;
  const notes: string[] = arr(value?.notes) as any;
  const socials: Social[] = arr(value?.socials) as any;

  const map = value?.map ?? {};
  const contacts = value?.contacts ?? {};

  return (
    <div className="space-y-6">
      <div>
        <div className="text-sm font-medium mb-1">Title</div>
        <Input
          value={value?.title ?? ""}
          onChange={(e) => onChange({ ...value, title: e.target.value })}
          placeholder="STUDIO ADDRESS"
        />
      </div>

      {/* Map */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="font-semibold">Map</div>

        <div>
          <div className="text-sm font-medium mb-1">Embed URL (iframe src)</div>
          <Input
            value={map?.embedUrl ?? ""}
            onChange={(e) => onChange({ ...value, map: { ...map, embedUrl: e.target.value } })}
            placeholder="https://www.google.com/maps/embed?..."
          />
          <div className="text-xs text-muted-foreground mt-1">
            Якщо embedUrl заповнений — він має пріоритет над imageSrc.
          </div>
        </div>

        <div>
          <div className="text-sm font-medium mb-1">Image URL (fallback)</div>
          <Input
            value={map?.imageSrc ?? ""}
            onChange={(e) => onChange({ ...value, map: { ...map, imageSrc: e.target.value } })}
            placeholder="https://..."
          />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">Alt</div>
            <Input
              value={map?.alt ?? ""}
              onChange={(e) => onChange({ ...value, map: { ...map, alt: e.target.value } })}
              placeholder="Studio location map"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Link URL (on click)</div>
            <Input
              value={map?.linkUrl ?? ""}
              onChange={(e) => onChange({ ...value, map: { ...map, linkUrl: e.target.value } })}
              placeholder="https://maps.google.com/?q=..."
            />
          </div>
        </div>
      </div>

      {/* Address */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Address lines</div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => onChange({ ...value, addressLines: [...addressLines, ""] })}
          >
            Add line
          </Button>
        </div>

        {addressLines.map((l, idx) => (
          <div key={idx} className="flex gap-2">
            <Input
              value={l ?? ""}
              onChange={(e) => onChange({ ...value, addressLines: setAt(addressLines, idx, e.target.value) })}
              placeholder={idx === 0 ? "580 LANCASTER AVE" : "MALVERN, PA 19455"}
            />
            <Button type="button" variant="destructive" onClick={() => onChange({ ...value, addressLines: removeAt(addressLines, idx) })}>
              Remove
            </Button>
          </div>
        ))}
      </div>

      {/* Notes (desktop only) */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Notes (desktop)</div>
          <Button type="button" variant="secondary" onClick={() => onChange({ ...value, notes: [...notes, ""] })}>
            Add note
          </Button>
        </div>

        {notes.map((l, idx) => (
          <div key={idx} className="flex gap-2">
            <Input
              value={l ?? ""}
              onChange={(e) => onChange({ ...value, notes: setAt(notes, idx, e.target.value) })}
              placeholder={idx === 0 ? "ACROSS FROM WAWA" : "OFF LANCASTER AVE"}
            />
            <Button type="button" variant="destructive" onClick={() => onChange({ ...value, notes: removeAt(notes, idx) })}>
              Remove
            </Button>
          </div>
        ))}
      </div>

      {/* Socials */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Socials</div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => onChange({ ...value, socials: [...socials, { icon: "instagram", href: "", label: "" }] })}
          >
            Add social
          </Button>
        </div>

        {socials.map((s, idx) => (
          <div key={idx} className="grid gap-2 md:grid-cols-[140px_1fr_1fr_auto] items-end">
            <div>
              <div className="text-sm font-medium mb-1">Icon</div>
              <select
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
                value={s?.icon ?? "instagram"}
                onChange={(e) =>
                  onChange({ ...value, socials: setAt(socials, idx, { ...s, icon: e.target.value as any }) })
                }
              >
                <option value="instagram">Instagram</option>
                <option value="facebook">Facebook</option>
              </select>
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Href</div>
              <Input
                value={s?.href ?? ""}
                onChange={(e) => onChange({ ...value, socials: setAt(socials, idx, { ...s, href: e.target.value }) })}
                placeholder="https://..."
              />
            </div>

            <div>
              <div className="text-sm font-medium mb-1">Label</div>
              <Input
                value={s?.label ?? ""}
                onChange={(e) => onChange({ ...value, socials: setAt(socials, idx, { ...s, label: e.target.value }) })}
                placeholder="Instagram"
              />
            </div>

            <Button type="button" variant="destructive" onClick={() => onChange({ ...value, socials: removeAt(socials, idx) })}>
              Remove
            </Button>
          </div>
        ))}
      </div>

      {/* Contacts */}
      <div className="rounded-xl border p-4 space-y-3">
        <div className="font-semibold">Contacts</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-sm font-medium mb-1">Phone</div>
            <Input
              value={contacts?.phone ?? ""}
              onChange={(e) => onChange({ ...value, contacts: { ...contacts, phone: e.target.value } })}
              placeholder="(610) 883-0878"
            />
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Email</div>
            <Input
              value={contacts?.email ?? ""}
              onChange={(e) => onChange({ ...value, contacts: { ...contacts, email: e.target.value } })}
              placeholder="SIMPLYDANCEPA@GMAIL.COM"
            />
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          Web сам згенерує <span className="font-mono">tel:</span> та <span className="font-mono">mailto:</span> якщо phone/email задані.
        </div>
      </div>
    </div>
  );
}
