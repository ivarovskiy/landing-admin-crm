"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { BLOCK_LIBRARY, DEFAULT_BLOCK_KEY, findBlockDef } from "@acme/block-library"

export function AddBlockForm({ pageId }: { pageId: string }) {
  const router = useRouter()

  const options = useMemo(
    () => [{ key: "custom", label: "Custom (manual)" }, ...BLOCK_LIBRARY.map((b) => ({ key: b.key, label: b.label }))],
    [],
  )

  const [selected, setSelected] = useState<string>(DEFAULT_BLOCK_KEY)
  const [type, setType] = useState("")
  const [variant, setVariant] = useState("")
  const [json, setJson] = useState("{}")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const def = selected === "custom" ? undefined : findBlockDef(selected)

  useEffect(() => {
    if (selected === "custom") return
    if (!def) return
    setType(def.type)
    setVariant(def.variant)
    setJson(JSON.stringify(def.defaultData ?? {}, null, 2))
  }, [selected, def])

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSaving(true)

    try {
      const data = JSON.parse(json)

      const t = selected === "custom" ? type.trim() : def?.type
      const v = selected === "custom" ? variant.trim() : def?.variant

      if (!t || !v) throw new Error("Type/variant required")

      const r = await fetch(`/api/admin/pages/${pageId}/blocks`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: t, variant: v, data }),
      })

      if (!r.ok) throw new Error(await r.text())
      setJson("{}")
      router.refresh()
    } catch (e: any) {
      setError(e?.message ?? "Create failed")
    } finally {
      setSaving(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3 rounded-xl border p-4">
      <div className="font-semibold">Add block</div>

      <div className="space-y-1">
        <div className="text-sm font-medium">Template</div>
        <select
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
          className="h-10 w-full rounded-md border bg-background px-3 text-sm"
        >
          {options.map((o) => (
            <option key={o.key} value={o.key}>
              {o.label}
            </option>
          ))}
        </select>
        {def?.description ? <div className="text-xs text-muted-foreground">{def.description}</div> : null}
      </div>

      {selected === "custom" ? (
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <div className="text-sm font-medium">Type</div>
            <Input value={type} onChange={(e) => setType(e.target.value)} />
          </div>
          <div className="space-y-1">
            <div className="text-sm font-medium">Variant</div>
            <Input value={variant} onChange={(e) => setVariant(e.target.value)} />
          </div>
        </div>
      ) : (
        <div className="text-sm text-muted-foreground">
          Creating: <b>{def?.type}</b> : <b>{def?.variant}</b>
        </div>
      )}

      <div className="space-y-1">
        <div className="text-sm font-medium">Data (JSON)</div>
        <Textarea value={json} onChange={(e) => setJson(e.target.value)} className="min-h-32 font-mono" />
      </div>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="secondary"
          onClick={() => {
            try {
              const obj = JSON.parse(json)
              setJson(JSON.stringify(obj, null, 2))
            } catch {
              setError("Invalid JSON")
            }
          }}
          disabled={saving}
        >
          Format
        </Button>

        <Button type="submit" disabled={saving}>
          {saving ? "Creating..." : "Create block"}
        </Button>
      </div>

      {error ? <div className="text-sm text-red-600 break-all">{error}</div> : null}
    </form>
  )
}