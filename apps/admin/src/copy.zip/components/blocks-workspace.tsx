"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AddBlockForm } from "@/components/add-block-form";
import { DeleteBlockButton } from "@/components/delete-block-button";
import { BlockVisibilityControls } from "@/components/block-visibility-controls";
import { BlockJsonPanel } from "@/components/block-json-panel";
import { ChevronDown, ChevronUp, Search } from "lucide-react";
import { BlockEditPanel } from "@/components/block-edit-panel";

type Block = {
  id: string;
  order: number;
  type: string;
  variant: string;
  data: any;
};

type Banner = { kind: "success" | "error"; message: string } | null;

export function BlocksWorkspace({
  pageId,
  blocks,
  initialActiveId,
}: {
  pageId: string;
  blocks: Block[];
  initialActiveId?: string;
}) {
  const router = useRouter();

  const sorted = useMemo(
    () => [...(blocks ?? [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0)),
    [blocks]
  );

  const [q, setQ] = useState("");
  const [activeId, setActiveId] = useState<string>(() => {
    if (initialActiveId && sorted.some((b) => b.id === initialActiveId)) return initialActiveId;
    return sorted[0]?.id ?? "";
  });

  const [banner, setBanner] = useState<Banner>(null);
  const [moving, setMoving] = useState<string | null>(null);

  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(null), 2500);
    return () => clearTimeout(t);
  }, [banner]);

  useEffect(() => {
    if (!activeId) {
      setActiveId(sorted[0]?.id ?? "");
      return;
    }
    if (!sorted.some((b) => b.id === activeId)) {
      setActiveId(sorted[0]?.id ?? "");
    }
  }, [sorted, activeId]);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return sorted;
    return sorted.filter((b) => `${b.type}:${b.variant}`.toLowerCase().includes(query));
  }, [sorted, q]);

  const active =
    filtered.find((b) => b.id === activeId) ??
    sorted.find((b) => b.id === activeId) ??
    sorted[0] ??
    null;

  async function move(blockId: string, direction: "up" | "down") {
    setMoving(blockId);
    setBanner(null);

    try {
      const r = await fetch(`/api/admin/blocks/${blockId}/move`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ direction }),
      });

      if (!r.ok) throw new Error(await r.text());

      setBanner({ kind: "success", message: "Reordered" });
      router.refresh();
    } catch (e: any) {
      setBanner({ kind: "error", message: e?.message ?? "Move failed" });
    } finally {
      setMoving(null);
    }
  }

  return (
    <div className="grid gap-4 md:grid-cols-[360px_1fr]">
      {/* Left */}
      <div className="rounded-xl border p-4 space-y-4 md:sticky md:top-4 md:max-h-[calc(100vh-6rem)] md:overflow-auto">
        <div className="font-semibold">Blocks</div>

        {banner ? (
          <div
            className={[
              "rounded-lg border px-3 py-2 text-sm",
              banner.kind === "success"
                ? "border-green-200 bg-green-50 text-green-800"
                : "border-red-200 bg-red-50 text-red-800",
            ].join(" ")}
          >
            {banner.message}
          </div>
        ) : null}

        <AddBlockForm pageId={pageId} />

        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
          <Input
            className="pl-9"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search type:variant…"
          />
        </div>

        <div className="space-y-2">
          {filtered.map((b, idx) => {
            const isActive = b.id === active?.id;
            const title = `#${b.order} ${b.type}:${b.variant}`;
            const isBusy = moving === b.id;

            return (
              <div
                key={b.id}
                className={[
                  "rounded-lg border p-3",
                  isActive ? "border-primary/40 bg-muted/30" : "hover:bg-muted/20",
                ].join(" ")}
              >
                <button type="button" onClick={() => setActiveId(b.id)} className="w-full text-left">
                  <div className="font-medium">{title}</div>
                  {b.data?._layout?.anchor ? (
                    <div className="text-xs text-muted-foreground">
                      anchor: {String(b.data._layout.anchor)}
                    </div>
                  ) : null}
                </button>

                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => move(b.id, "up")}
                    disabled={idx === 0 || isBusy}
                    title="Move up"
                    type="button"
                  >
                    <ChevronUp className="h-4 w-4" />
                  </Button>

                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => move(b.id, "down")}
                    disabled={idx === filtered.length - 1 || isBusy}
                    title="Move down"
                    type="button"
                  >
                    <ChevronDown className="h-4 w-4" />
                  </Button>

                  <DeleteBlockButton
                    blockId={b.id}
                    onResult={(r) =>
                      setBanner({
                        kind: r.ok ? "success" : "error",
                        message: r.message ?? (r.ok ? "Done" : "Failed"),
                      })
                    }
                  />

                  <BlockVisibilityControls blockId={b.id} initial={b.data} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right */}
      <div className="space-y-4 md:sticky md:top-4 md:max-h-[calc(100vh-6rem)] md:overflow-auto">
        {active ? (
          <BlockEditPanel
            blockId={active.id}
            title={`#${active.order} ${active.type}:${active.variant}`}
            type={active.type}
            variant={active.variant}
            initial={active.data}
          />
        ) : (
          <div className="rounded-xl border p-6 text-sm text-muted-foreground">No blocks found.</div>
        )}
      </div>
    </div>
  );
}